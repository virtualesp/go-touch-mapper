import logo from './logo.svg';
import './App.css';
import Manager from "./components/Manager";
function App() {
  return (
   <Manager/>
  );
}

export default App;
